#' transform data.table read by function readDB()
#'
#' @param df data.table,whichloc character
#'
#' @return data.table
#' @export

db2dt <- function(df,whichloc='Z') {
  df2 <- melt(df,
             measure.vars = c(5:10,4),
             variable.name = 'weekname',
             value.name = 'week'
  )[week=='T'] |>
    within(week <- as.integer(weekname))

  df3 <-
    cbind(
      rbindlist(
        lapply(1:4,\(x) df2[,c(names(df2[1,row_id:nationwide]),'week'),with=F])
      )
      ,
      rbindlist(
        list(
          df2[,flightnumber1:loc2],
          df2[,flightnumber2:loc3],
          df2[,flightnumber3:loc4],
          df2[,flightnumber4:loc5]
        ),use.names = F
      )
    )[loc2!='',-'flightnumber2']

  df4 <- rbindlist(
    list(
      within(df3,{sta1=NULL;type='dep'}),
      subset(df3,select=c(names(df3[1,row_id:flightnumber1]),'loc2','sta1','loc1')) |>
        within(type <- 'arr')
    ),use.names = F
  )[loc1 %like% paste0('^',whichloc)&(std1!='')] |>
    setnames(c('id','flt','awy','nwd','week','fln','loc1','slot','loc2','type'))

  return(df4)
}

