#' read paradox db exported text files
#'
#' @param path character
#'
#' @return data.table
#' @export
#'
readDB <-
  function(path){
    library(data.table,quietly = T)

    enc2gbk <- function(x) {
      readr::parse_character(x, locale = readr::locale(encoding = 'gbk'))}  # 自定义函数enc2gbk, 使用readr包

    f <-fread(
      path,
      colClasses = 'character',
      fill = T,
      select = c(1:29, 44:46, 55, 58),
      blank.lines.skip = T,data.table = T
    ) |>
      setnames(tolower) |>

    within({
      nationwide = enc2gbk(nationwide) # 修改编码为gbk
      confirm = enc2gbk(confirm)
      remark = enc2gbk(remark)
      sunday = enc2gbk(sunday)
      kh = enc2gbk(loc9)
    }
  )

    y <- f[!f$confirm %in% c('已进入', '未进入')]  # 筛选因remark里用了\t导致的错位
    r <- rbindlist(list(f[confirm == '已进入'],
                   y[c(y$sunday[-1] == '已进入', F)]))   # 修正错位的行

    return(r)
  }

